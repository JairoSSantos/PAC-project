# PAC backend

Requisitos: [Docker Engine](https://docs.docker.com/engine/install/), [Docker Compose](https://docs.docker.com/compose/install/)

Após abrir o terminal no local do arquivo ```docker-compose.yml```, execute
~~~console
docker-compose up -d
~~~